package com.survey.site.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveySiteBackendApi10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
